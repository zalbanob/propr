import os

def print_tree(root_path, prefix=""):
    """
    Recursively prints the directory tree starting at root_path, using prefix for indentation.
    Files are printed as leaves; directories are recursed into.
    """
    # List all entries in the directory, sorted so directories and files are in a stable order
    try:
        entries = sorted(os.listdir(root_path))
    except PermissionError:
        print(f"{prefix}[Permission Denied]")
        return

    for idx, entry in enumerate(entries):
        path = os.path.join(root_path, entry)
        is_last = (idx == len(entries) - 1)
        connector = "└── " if is_last else "├── "

        print(prefix + connector + entry)

        if os.path.isdir(path):
            # Prepare the next prefix: use "    " if this was the last entry, else "│   "
            extension = "    " if is_last else "│   "
            print_tree(path, prefix + extension)

def print_selected_subtrees(base_dir, subdirs):
    """
    For each name in subdirs, checks if it exists under base_dir. If so, prints the tree
    of that subdirectory; otherwise, warns that it doesn't exist.
    """
    for i, sub in enumerate(subdirs):
        full_path = os.path.join(base_dir, sub)
        if os.path.isdir(full_path):
            header = f"{sub}/"
            print(header)
            # Call print_tree on the selected subdirectory, with an empty prefix
            print_tree(full_path, prefix="")
            # Print a blank line after each subtree (except maybe after the last one)
            if i < len(subdirs) - 1:
                print()
        else:
            print(f"[Warning] '{sub}' is not a directory under {base_dir}\n")

if __name__ == "__main__":
    # Example usage:
    # Change this to your own base directory
    base_directory = "/gpfs/projects/bsc99/bsc099260/EuroHPC/PROPR/SRC/PORTED/propr"

    # List the subdirectories (relative to base_directory) you want to print
    selected_subdirs = [
        "./bench",
        "./R",
        "./prereq",
        "./src",
        "./tests"
    ]

    print_selected_subtrees(base_directory, selected_subdirs)

